@extends('template')
@section('container')

  <div class="col-xs-12">
    <div class="card">
      <div class="header">
        <h2>Dashboard</h2>
      </div>
      <div class="body">
        <h2 align="center">Selamat Datang!</h2>
      </div>
    </div>
  </div>
  @stop
