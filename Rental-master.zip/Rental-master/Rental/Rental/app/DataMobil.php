<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataMobil extends Model
{
    //
}
