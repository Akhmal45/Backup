<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class petugas extends Model
{
    //
}
