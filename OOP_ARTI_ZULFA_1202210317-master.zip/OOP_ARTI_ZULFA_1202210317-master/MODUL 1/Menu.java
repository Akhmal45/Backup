public class Menu {

    String food;
    String kind;


    // TODO Create Attribute of Menu; Name, Category, and Price then Create Setter

    public String getFood() {
        
        return food;
    }

    public String getKind() {
        return food;
    }


}
