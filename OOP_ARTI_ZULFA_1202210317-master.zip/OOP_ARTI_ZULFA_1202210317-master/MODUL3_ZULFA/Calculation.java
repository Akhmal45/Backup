package MODUL3_ZULFA;

public class Calculation {
    double radius;
    double side;
    double area;
    double phi;

    public void setSquare(double side) {

    }

    public void getSquare() {

    }

    public void setCircle() {

    }

    public void getCircle() {

    }

    public void setTrapezoid() {

    }

    public void getTrapezoid() {

    }

    public void run() {

    }

}
